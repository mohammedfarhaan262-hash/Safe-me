
// Safe Me - 3D endless runner (Three.js)
// Swipe-only controls. Designed to be opened directly in a mobile browser (index.html).

(function () {
  const canvasWidth = window.innerWidth;
  const canvasHeight = window.innerHeight;

  // Scene setup
  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x000000, 0.0012);

  const camera = new THREE.PerspectiveCamera(60, canvasWidth / canvasHeight, 0.1, 1000);
  camera.position.set(0, 5, 12);
  camera.lookAt(0, 2, 0);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(canvasWidth, canvasHeight);
  renderer.setPixelRatio(window.devicePixelRatio ? window.devicePixelRatio : 1);
  document.body.appendChild(renderer.domElement);

  // Lighting
  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.9);
  hemi.position.set(0, 50, 0);
  scene.add(hemi);

  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(-3, 10, 5);
  scene.add(dir);

  // Textures - large BMPs generated in assets/textures/
  const loader = new THREE.TextureLoader();
  const textures = [];
  const texNames = [
    "assets/textures/tex_1.bmp",
    "assets/textures/tex_2.bmp",
    "assets/textures/tex_3.bmp",
    "assets/textures/tex_4.bmp"
  ];
  texNames.forEach(n => {
    textures.push(loader.load(n));
  });

  // Ground / track pieces
  const trackGroup = new THREE.Group();
  scene.add(trackGroup);

  const laneX = [-3, 0, 3]; // three lanes positions
  const player = new THREE.Mesh(
    new THREE.BoxGeometry(1.2, 1.6, 1.2),
    new THREE.MeshStandardMaterial({ color: 0x00aaff })
  );
  player.position.set(0, 1, 0);
  scene.add(player);

  // environment pieces (recycled)
  const pieceLength = 10;
  const numPieces = 12;
  const pieces = [];
  for (let i = 0; i < numPieces; i++) {
    const geom = new THREE.BoxGeometry(12, 0.5, pieceLength);
    const mat = new THREE.MeshStandardMaterial({ map: textures[i % textures.length] });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(0, -0.25, -i * pieceLength);
    trackGroup.add(mesh);
    pieces.push(mesh);
  }

  // Obstacles and coins (pooled)
  const obstaclePool = [];
  const coinPool = [];
  const maxObstacles = 40;
  const maxCoins = 80;

  // create pools
  const obsGeom = new THREE.BoxGeometry(1.5, 1.5, 1.5);
  const obsMat = new THREE.MeshStandardMaterial({ color: 0x885522 });
  for (let i = 0; i < maxObstacles; i++) {
    const m = new THREE.Mesh(obsGeom, obsMat);
    m.visible = false;
    scene.add(m);
    obstaclePool.push(m);
  }
  const coinGeom = new THREE.TorusGeometry(0.45, 0.18, 8, 16);
  const coinMat = new THREE.MeshStandardMaterial({ color: 0xffd700, emissive:0xffd700 });
  for (let i = 0; i < maxCoins; i++) {
    const c = new THREE.Mesh(coinGeom, coinMat);
    c.rotation.x = Math.PI/2;
    c.visible = false;
    scene.add(c);
    coinPool.push(c);
  }

  // Game state
  let lane = 1; // start at middle
  let targetX = laneX[lane];
  let lateralSpeed = 0.15;
  let forwardSpeed = 0.25; // movement of world towards player
  let speedIncrease = 0.00001;
  let jumpVelocity = 0;
  let gravity = -0.035;
  let isJumping = false;
  let score = 0;
  let running = false;
  let gameover = false;

  // Audio
  const audioBg = new Audio("assets/sounds/bg_long.wav");
  audioBg.loop = true;
  audioBg.volume = 0.6;
  const audioCoin = new Audio("assets/sounds/coin.wav");
  const audioJump = new Audio("assets/sounds/jump.wav");
  const audioGame = new Audio("assets/sounds/gameover.wav");

  // UI elements
  const overlay = document.getElementById("overlay");
  const startBtn = document.getElementById("startBtn");
  const scoreEl = document.getElementById("score");
  const gameoverBox = document.getElementById("gameoverBox");
  const finalScore = document.getElementById("finalScore");
  const restartBtn = document.getElementById("restartBtn");

  startBtn.addEventListener("click", startGame);
  restartBtn.addEventListener("click", restartGame);

  function startGame() {
    overlay.style.display = "none";
    running = true;
    gameover = false;
    score = 0;
    audioBg.currentTime = 0;
    audioBg.play().catch(()=>{});
  }

  function restartGame() {
    obstaclePool.forEach(o => { o.visible=false; });
    coinPool.forEach(c => { c.visible=false; });
    for (let i = 0; i < pieces.length; i++) pieces[i].position.z = -i * pieceLength;
    player.position.set(0,1,0);
    lane = 1; targetX = laneX[lane]; forwardSpeed = 0.25; isJumping=false; jumpVelocity=0;
    score = 0; scoreEl.textContent = score; gameover = false; gameoverBox.style.display = "none";
    overlay.style.display = "none";
    running = true;
    audioBg.currentTime=0; audioBg.play().catch(()=>{});
  }

  // Swipe detection (touch only)
  let touchStartX = 0, touchStartY = 0, touchEndX = 0, touchEndY = 0;
  let touchMoved = false;
  const minSwipe = 30;

  renderer.domElement.addEventListener("touchstart", (e) => {
    const t = e.touches[0];
    touchStartX = t.clientX; touchStartY = t.clientY; touchMoved=false;
  }, {passive:true});

  renderer.domElement.addEventListener("touchmove", (e) => {
    touchMoved = true;
    const t = e.touches[0];
    touchEndX = t.clientX; touchEndY = t.clientY;
  }, {passive:true});

  renderer.domElement.addEventListener("touchend", (e) => {
    if(!touchMoved) return;
    const dx = touchEndX - touchStartX;
    const dy = touchEndY - touchStartY;
    if(Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > minSwipe) {
      if(dx > 0) swipeRight();
      else swipeLeft();
    } else if(Math.abs(dy) > Math.abs(dx) && Math.abs(dy) > minSwipe) {
      if(dy < 0) swipeUp();
    }
  }, {passive:true});

  function swipeLeft() {
    if(!running || gameover) return;
    lane = Math.max(0, lane-1);
    targetX = laneX[lane];
  }
  function swipeRight() {
    if(!running || gameover) return;
    lane = Math.min(2, lane+1);
    targetX = laneX[lane];
  }
  function swipeUp() {
    if(!running || gameover) return;
    if(!isJumping) {
      isJumping = true;
      jumpVelocity = 0.6;
      audioJump.currentTime = 0; audioJump.play().catch(()=>{});
    }
  }

  // Spawning obstacles and coins randomly ahead
  let spawnZ = -50;
  function spawnEntities() {
    if(Math.random() < 0.4) {
      const o = obstaclePool.find(x=>!x.visible);
      if(o) {
        const laneIdx = Math.floor(Math.random()*3);
        o.position.set(laneX[laneIdx], 0.75, spawnZ);
        o.visible = true;
      }
    }
    const coinCount = Math.random() < 0.6 ? (1 + Math.floor(Math.random()*3)) : 0;
    for(let i=0;i<coinCount;i++){
      const c = coinPool.find(x=>!x.visible);
      if(c) {
        const laneIdx = Math.floor(Math.random()*3);
        c.position.set(laneX[laneIdx], 1.1, spawnZ - (i*2));
        c.visible = true;
      }
    }
    spawnZ -= (5 + Math.random()*8);
  }

  for(let i=0;i<12;i++) spawnEntities();

  // Collision checking helper
  const playerBox = new THREE.Box3();
  const tmpBox = new THREE.Box3();

  // Animation loop
  let lastTime = performance.now();
  function animate() {
    const now = performance.now();
    const dt = (now - lastTime) / 16.666;
    lastTime = now;

    if(running && !gameover) {
      for(let i=0;i<pieces.length;i++){
        pieces[i].position.z += forwardSpeed * dt * 10;
        if(pieces[i].position.z > pieceLength){
          pieces[i].position.z -= pieceLength * pieces.length;
        }
      }
      obstaclePool.forEach(o => {
        if(o.visible){
          o.position.z += forwardSpeed * dt * 10;
          if(o.position.z > 10) o.visible = false;
        }
      });
      coinPool.forEach(c => {
        if(c.visible){
          c.position.z += forwardSpeed * dt * 10;
          c.rotation.z += 0.2 * dt;
          if(c.position.z > 10) c.visible = false;
        }
      });

      if(Math.random() < 0.08) spawnEntities();
      forwardSpeed += speedIncrease * dt;
      player.position.x += (targetX - player.position.x) * lateralSpeed * dt;

      if(isJumping) {
        player.position.y += jumpVelocity * dt;
        jumpVelocity += gravity * dt;
        if(player.position.y <= 1) {
          player.position.y = 1;
          isJumping = false;
          jumpVelocity = 0;
        }
      }

      playerBox.setFromObject(player);
      obstaclePool.forEach(o => {
        if(o.visible) {
          tmpBox.setFromObject(o);
          if(playerBox.intersectsBox(tmpBox)) {
            doGameOver();
          }
        }
      });

      coinPool.forEach(c => {
        if(c.visible) {
          tmpBox.setFromObject(c);
          if(playerBox.intersectsBox(tmpBox)) {
            c.visible = false;
            score += 10;
            scoreEl.textContent = score;
            audioCoin.currentTime = 0; audioCoin.play().catch(()=>{});
          }
        }
      });
    }

    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();

  function doGameOver() {
    gameover = true;
    running = false;
    audioBg.pause();
    audioGame.currentTime = 0; audioGame.play().catch(()=>{});
    finalScore.textContent = score;
    gameoverBox.style.display = "block";
    overlay.style.display = "none";
  }

  window.addEventListener("resize", ()=>{
    const w = window.innerWidth, h = window.innerHeight;
    renderer.setSize(w,h);
    camera.aspect = w/h;
    camera.updateProjectionMatrix();
  });

  document.body.addEventListener('touchmove', function(e){ if(running) e.preventDefault(); }, {passive:false});
})();
